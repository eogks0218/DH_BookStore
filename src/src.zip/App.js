import Main from "./components/Main";
import styled from "styled-components";
import { Routes, Route } from "react-router-dom";
import Introduce from "./components/Introduce";
import BestSellers from "./components/BestSellers/BestSellers"
import DomesticBooks from "./components/DomesticBooks";
import ForeignBooks from "./components/ForeignBooks";
import HotNewProduct from "./components/HotNewProducts";


const Div = styled.div `
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`

function App() {
    return (
        <Div>
          <Routes>
            <Route path='/' element={<Main />} />
            <Route path='/introduce' element={<Introduce />} />
            <Route path='/bestSellers' element={<BestSellers />} />
            <Route path='/domesticBooks' element={<DomesticBooks />} />
            <Route path='/foreignBooks' element={<ForeignBooks />} />
            <Route path='/hotNewProduct' element={<HotNewProduct />} />
          </Routes>
        </Div>
    );
}

export default App;
