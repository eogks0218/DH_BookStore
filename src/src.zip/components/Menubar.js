import {FaBook} from "react-icons/fa"
import {Link} from "react-router-dom";
import "../scss/MenuBar.scss"

const Menubar = () => {
    return (
        <div className="menuBox">
            <nav>
                <ul>
                    <li>
                        <Link to="/"><FaBook /></Link>
                    </li>
                    <li>
                        <Link to="/Introduce">Introduce</Link>
                    </li>
                    <li>
                        <Link to="/bestSellers">Best Sellers</Link>
                    </li>
                    <li>
                        <Link to="/domesticBooks">Domestic books</Link>
                    </li>
                    <li>
                        <Link to="/foreignBooks">Foreign books</Link>
                    </li>
                    <li>
                        <Link to="/hotNewProduct">Hot New Product</Link>
                    </li>
                </ul>
            </nav>
        </div>
    )
}

export default Menubar;