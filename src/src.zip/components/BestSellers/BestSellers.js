import Menubar from '../Menubar';
import styled from 'styled-components';
import './scss/BestSellers.scss'
import BestSellersSelect from './BestSellersSelect';
import { useSelector, useDispatch } from 'react-redux';
import { change_year } from '../../modules/bestSellers';

const Div = styled.div `
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
`

function BestSellers(){

    const selectedYear = useSelector(state=>state.bestSellers.year)
    const dispatch = useDispatch()

    return (
        <Div>
            <Menubar />
            <div className='twoDiv'>
                <select className='select' onChange={(e)=>dispatch(change_year(e.target.value))}>
                    <option value='2023'>2023년</option>
                    <option value='2022'>2022년</option>
                    <option value='2021'>2021년</option>
                </select>
            </div>
            <BestSellersSelect selectedYear={selectedYear}/>
        </Div>
    )
}

export default BestSellers;