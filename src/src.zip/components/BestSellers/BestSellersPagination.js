import { useCallback, useState } from "react";
import bsDataFile2023 from '../../data/BestSellers2023.json'
import bsDataFile2022 from '../../data/BestSellers2022.json'
import bsDataFile2021 from '../../data/BestSellers2021.json'
import './scss/BestSellers.scss'
import { TiHeartOutline } from "react-icons/ti";
import { TiHeart } from "react-icons/ti";
import { useSelector, useDispatch } from "react-redux";
import { shopping_basket } from "../../modules/bestSellers";

function Pagination({totalItems, itemsPerPage, imgList, selectedYear}){

    const dispatch = useDispatch()

    const [currentPage, setCurrentPage] = useState(1);

    const totalPage = Math.ceil(totalItems / itemsPerPage);

    const pageNumbers = Array.from({length: totalPage}, (_, index)=>(index+1))

    const handleClick = useCallback((page)=>{
        setCurrentPage(page)
    }, [])
    const startIndex = (currentPage-1)*itemsPerPage
    const endIndex = startIndex + itemsPerPage;

    const bsDataFile = { "2023" : bsDataFile2023, "2022" : bsDataFile2022, "2021" : bsDataFile2021}

    const DataSelect = bsDataFile[selectedYear]

    const shoppingBasket = (productId, selectedYear) => {
        dispatch(shopping_basket(productId, selectedYear))
    }
    
    const displayItems = Array.from({length: totalItems}, (_, index)=>(index+1))
                        .slice(startIndex, endIndex)
                        .map((item, index)=>
                            <div key={index} className="item">
                                {DataSelect
                                    .filter(data => data.id === item) // 먼저 조건에 맞는 요소만 필터링
                                    .map((data) =>{
                                        return(
                                            <div className="item-container">
                                                <div className="img-container">
                                                    <img src={imgList[data.id-1]} alt="" width='130px'/>
                                                </div>
                                                <div className="info-container">
                                                    <div className="item-name">{data.name}</div>
                                                    <div className="item-author">Author : {data.author}</div>
                                                    <div className="item-introduce">{data.introduce}</div>
                                                    <div className="item-price">Price : {data.price} </div>
                                                </div>
                                                <div className="item-checked">
                                                    <p>담기</p>
                                                    {data.checked? <TiHeart onClick={()=>shoppingBasket(data.id-1, selectedYear)} style={{color: 'red'}}/> : <TiHeartOutline onClick={()=>shoppingBasket(data.id-1, selectedYear)}/>}
                                                </div>
                                            </div>
                                        )
                                })}
                            </div>
                        )

    return(
        <div className="pagination-container">
            <div className="items">{displayItems}</div>
            <ul className='page-numbers'>
                {pageNumbers.map((Number)=>
                    <li key={Number}
                    className={Number === currentPage ? 'active' : ''}
                    onClick={()=>handleClick(Number)}>
                        {Number}
                    </li>
                )}
            </ul>
        </div>
    )
}

export default Pagination;
