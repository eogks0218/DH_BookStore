import Menubar from './Menubar';
import styled from 'styled-components';

const Div = styled.div `
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`

function Introduce(){
    return (
        <Div>
            <Menubar />
            <div className='container'>
                <h1>Introduce</h1>
            </div>
        </Div>
    )
}

export default Introduce;