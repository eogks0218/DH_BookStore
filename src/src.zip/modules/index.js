import { combineReducers } from "redux";
import { bestSellers } from "./bestSellers";

const rootReducer = combineReducers({
    bestSellers
});

export default rootReducer;