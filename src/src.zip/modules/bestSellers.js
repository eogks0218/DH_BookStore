import bsDataFile2023 from '../data/BestSellers2023.json'
import bsDataFile2022 from '../data/BestSellers2022.json'
import bsDataFile2021 from '../data/BestSellers2021.json'

const bsDataFile = { "2023" : bsDataFile2023, "2022" : bsDataFile2022, "2021" : bsDataFile2021}

const CHANGE_YEAR = 'bestSellers/CHANGE_YEAR';
const SHOPPING_BASKET = 'bestSellers/SHOPPING_BASKET';

export const change_year = (year) => ({type: CHANGE_YEAR, year});
export const shopping_basket = (product, year) => ({type: SHOPPING_BASKET, product, year});

const initialState = {
    year: 2023,
    dataSelect: bsDataFile["2023"]
}

export const bestSellers = (state=initialState, action) => {
    switch (action.type){
        case CHANGE_YEAR:
            return {
                ...state,
                year: action.year,
                dataSelect: bsDataFile[action.year]
            }
        case SHOPPING_BASKET:
                const data = bsDataFile[action.year]
                const newData = data.map((item, index) => {
                    if (index === action.product) {
                        return {
                            ...item,
                            checked: !item.checked
                        };
                    } else {
                        return item;
                    }
                });
                console.log(newData[action.product].checked)
            return {
                ...state,
                year: action.year,
                dataSelect: newData
            }
        default:
            return state;
    }
}